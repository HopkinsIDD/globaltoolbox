library(testthat)
library(globaltoolbox)

test_check("globaltoolbox")
